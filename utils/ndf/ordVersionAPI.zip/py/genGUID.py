from uuid import uuid4


if __name__ == "__main__":
    print(str(uuid4()))