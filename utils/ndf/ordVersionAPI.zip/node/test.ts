/**
 * @file test.ts
 * @author edocsitahw
 * @version 1.1
 * @date 2024/12/20 上午10:34
 * @desc
 * */

import * as fs from 'fs';
import * as path from 'path';
import {Lexer} from "./src/lexer/lexer";
import {Processor} from "./src/lexer/processor";
import {Parser} from "./src/parser/parser";
import {Analyser} from "./src/parser/analysis";
import * as CircularJSON from 'circular-json';
import {InternalNode, LeafNode, Visitor} from "./src/parser/ast";
import {GeneralAST, Nullable} from "./src/types";


const data = fs.readFileSync(path.join(__dirname, 'ins.ndf'), 'utf8');

const lexer = new Lexer(data);
const tokens = lexer.tokenize();

//for (const token of tokens)
//    console.log(token.toString());
for (const error of lexer.errors)
    console.log(error.message, error.start, error.end);

const processor = new Processor(tokens);
const processedTokens = processor.process(false);

//for (const token of processedTokens)
//    console.log(token.toString());

const parser = new Parser(processedTokens);
const program = parser.parse();

for (const error of parser.errors)
    console.log(error.message, error.start, error.end);

//console.log(JSON.stringify(program.toJSON()));

const analyser = new Analyser(program, false, true);
const scope = analyser.analyze();

for (const error of analyser.errors)
    // @ts-ignore
    console.log(error.message, error.start, error.end);

//console.log(CircularJSON.stringify(scope.toJSON()));

//Visitor.visit(program, (node: LeafNode | InternalNode) => {
//    console.log(node.nodeName, node.pos);
//    return undefined;
//});
